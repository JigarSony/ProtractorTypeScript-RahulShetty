//print something in console
console.log("Hello World!");

//for comment "//"

//DataTypes
var a=1;
var b = "Hello";

console.log(a);
console.log(b);

//condition
/*
 * Condition -- True 
 *execute this block of code
 *
 *false
 *execute another code
 */
//-----------------If-Else-------------------
if(a==2){
	console.log("Yes");
}else{
	console.log("No");
}

//------------If-Else-If---------
var c="one"
if(c=="one"){
		console.log("One");
		}
else if (c="two") {
	console.log("Two");
	}
else if(c="three"){
	console.log("three");
}
else{
	console.log("Nothing");
}

//-----------------for-----------------

for(var i=1;i<=100;i++){
	//console.log(i);
}

//------------------While loop -------------
var j = 1;
while (j<5) {
	console.log(j);
	j++;
}
//-----------do-While------------
var k = 10;

do
	{
	console.log(k);
	k++;
	}while(k<9)