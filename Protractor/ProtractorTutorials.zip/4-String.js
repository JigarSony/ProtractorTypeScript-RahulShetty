var name ="Rahul"; // String literal declaration

console.log(name.charAt(3));

var newname=name.concat("Shetty");
console.log(newname);

console.log(name.indexOf("u"));

console.log(name.slice(1, 4));
//starting index is inclusive - ending index is exclusive

console.log(name.toUpperCase());

var name ="Rahul ";

console.log(name.trim());

var name2=new String("Rahul"); 
// string object declaration